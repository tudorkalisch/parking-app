package com.parkingpp.parkingppbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
