package com.parkingpp.parkingppbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingppBackendApplication.class, args);
	}

}
